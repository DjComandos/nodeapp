// "server.js" file required at the root directory according to this doc
// http://docs.aws.amazon.com/opsworks/latest/userguide/workinglayers-node.html
require('./server/server.js').start();